# YuDeck — Android cloud-build project

This is a phone-friendly Android Studio/Gradle project with a GitHub Actions workflow that builds a debug APK in the cloud.

## Build an APK using only your Android phone

1. Sign in to GitHub in your phone browser and create a **new private repository** named `YuDeck`.
2. Upload the contents of this ZIP to the repository (not the enclosing folder). Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. Select **Build YuDeck APK**, then tap **Run workflow**. You can also push a commit to `main` to trigger it.
4. Wait for the workflow to finish successfully.
5. Open that workflow run, scroll to **Artifacts**, and download `YuDeck-debug-apk`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser/files app.

## Important current limitations

This is an early installable foundation, not the finished feature-complete product:
- The settings screen currently demonstrates gallery pickers and theme selection, but selections are not yet persisted or applied to the widget.
- The widget opens a compact YuDeck folder-style activity. Android does not let a regular third-party widget invoke the launcher's own native folder popup.
- The app list, per-app custom icons, and actual launch actions are not implemented yet.
- The home-screen wallpaper picker is a selection prototype; it does not change Android's system wallpaper.
- Build output is a debug APK, suitable for testing, not a Play Store release.

## Requirements

GitHub account and Android phone. No PC or Android Studio is required for the cloud build.
