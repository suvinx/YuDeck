package com.yudeck.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Plum = Color(0xFF241A38)
private val Pink = Color(0xFFF4B8D3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YuDeckHome() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YuDeckHome() {
    var wallpaper by remember { mutableStateOf<Uri?>(null) }
    var popupArt by remember { mutableStateOf<Uri?>(null) }
    var folderIcon by remember { mutableStateOf<Uri?>(null) }
    var profileArt by remember { mutableStateOf<Uri?>(null) }
    var chosenTheme by remember { mutableStateOf("Sakura Night") }
    val pickWallpaper = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { wallpaper = it }
    val pickPopup = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { popupArt = it }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { folderIcon = it }
    val pickProfile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { profileArt = it }

    MaterialTheme(colorScheme = darkColorScheme(primary = Pink, background = Plum, surface = Color(0xFF352747))) {
        Scaffold(containerColor = Plum, topBar = {
            TopAppBar(title = { Text("YuDeck 🌸", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Plum))
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Make your phone feel like yours.", color = Pink, fontSize = 18.sp)
                Text("PERSONALIZATION", color = Pink, style = MaterialTheme.typography.labelLarge)
                CustomRow("Home-screen wallpaper", "Choose from your gallery", Icons.Default.Wallpaper) { pickWallpaper.launch("image/*") }
                CustomRow("Folder popup background", "Its own separate picture", Icons.Default.Image) { pickPopup.launch("image/*") }
                CustomRow("1×1 widget cover", "Choose your folder artwork", Icons.Default.Folder) { pickIcon.launch("image/*") }
                CustomRow("Profile picture", "Choose a profile image", Icons.Default.Person) { pickProfile.launch("image/*") }
                Text("THEMES", color = Pink, style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Sakura Night", "Lavender", "Midnight").forEach { theme ->
                        FilterChip(selected = chosenTheme == theme, onClick = { chosenTheme = theme }, label = { Text(theme) })
                    }
                }
                Text("PREVIEW", color = Pink, style = MaterialTheme.typography.labelLarge)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF463455)), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🌸", fontSize = 34.sp)
                        Text("YuDeck Folder", color = Color.White)
                        Text("Your popup artwork and app layout will appear here.", color = Color(0xFFE7D8F0))
                    }
                }
                Text("Add the YuDeck 1×1 widget from your phone's Widgets menu.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun CustomRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color(0xFF352747)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Pink, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White)
                Text(subtitle, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.AddPhotoAlternate, null, tint = Pink)
        }
    }
}
