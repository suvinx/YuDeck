package com.yudeck.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Compact folder-style screen launched from the home-screen widget.
// Android launchers do not expose an API for third-party widgets to open their native folder UI.
class FolderActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = Color(0xEE291D3A), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🌸 YuDeck", color = Color.White, fontSize = 22.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("Your selected apps will appear here.", color = Color.White)
                        Spacer(Modifier.height(12.dp))
                        Text("Open YuDeck settings to personalize your folder.", color = Color(0xFFE8CBE0))
                    }
                }
            }
        }
    }
}
